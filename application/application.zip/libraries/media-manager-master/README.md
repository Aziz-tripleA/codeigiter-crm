# Codeigniter-Mediagalley
Media gallery module using Codeigniter With Prevent Adult Content Upload

# ScreenShot

<img src="https://raw.githubusercontent.com/Guley/media-manager/master/Screenshot_1.png">
<img src="https://raw.githubusercontent.com/Guley/media-manager/master/Screenshot_3.png">
<img src="https://raw.githubusercontent.com/Guley/media-manager/master/Screenshot_02.png">
