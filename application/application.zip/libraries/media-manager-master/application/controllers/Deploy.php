array(
    'codeigniter-media-manager' => array(
        'master' => array('base_path' => '/path/PHP-Git-Deploy_1/'),
        'develop' => array('base_path' => '/path/PHP-Git-Deploy_2/')
    )
);
