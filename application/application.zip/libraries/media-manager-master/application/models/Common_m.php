<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_m extends MY_Model {

	

}