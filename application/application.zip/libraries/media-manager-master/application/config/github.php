$config['github'] = array(
    'Codeigniter-media-manager' => array(
        'branch_name' => array('base_path' => 'https://github.com/Guley/Codeigniter-media-manager/')
    )
);
