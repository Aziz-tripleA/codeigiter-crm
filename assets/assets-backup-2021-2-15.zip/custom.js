$(document).ready(function () {

    'use strict';

    $(".se-pre-con").fadeOut("slow");


    //summernote
    $('#summernote').summernote({
        height: 300, // set editor height
        minHeight: null, // set minimum height of editor
        maxHeight: null, // set maximum height of editor
        focus: true                  // set focus to editable area after initializing summernote
    });

    // tiemt picker
    $('#basic_example_1').timepicker();
    $('#basic_example_2').timepicker();

    //date picker
    $(".datepicker1").datepicker(
    {
        dateFormat: 'yy-mm-dd',
        showMonths: true,
        changeMonth: true,
        changeYear: true,
        yearRange: "-100:+0"
    });


    $(".datepicker2").datepicker({dateFormat: 'yy-mm-dd'});

    $(".datepicker3").datepicker(
    {
    showOtherMonths: true,
    selectOtherMonths: true,
    dateFormat: 'yy-mm-dd',
    minDate: 0
    });
 
 
});




    // load patient name
    function loadName(){
        'use strict';          
        var phone = $('#phone').val();;

        var base_url = $("#base_url").val();

        if (phone!='') {

            $('button[type=submit]').prop('disabled', true);

            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/get_patinet_name/'+phone.trim(),
                'type': 'GET', //the way you want to send data to your URL
                'data': {'phone': phone },
                'success': function(data) { 
                    var container = $(".patient_name");
                    if(data==0){
                        container.html("<?php echo display('patient_name_load_msg')?>");
                    }else{ 
                        container.html(data);
                        $('button[type=submit]').prop('disabled', false);
                    }
                }
            });
        };
    }

    // load load schedul
    function loadSchedul(){
        'use strict'; 
        var doctor_id = $('#doctor_id').val();
        var date     = $('#date').val();
        var base_url = $("#base_url").val();

        
        if (doctor_id!='') {
            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/get_schedul/'+doctor_id+'/'+date,
                'type': 'GET', //the way you want to send data to your URL
                'data': {'doctor_id': doctor_id },
                'success': function(data) {
                    var container = $(".schedul");
                    container.html(data);
                }
                });
            };
    }

    // sequence uncion
    function myBooking(data){
        'use strict'; 
        var id = $("#t_" + data).text();
        document.getElementById("msg_c").innerHTML = "<div style=' color:green; font-size:20px;'><?php echo display('book_sequence')?> " +id +"</div>";
        document.getElementById('serial_no').value = id;        
    } 



    // start create patient
    $(document).ready(function(){

        'use strict';

        var base_url = $("#base_url").val();

        $("#old").on('keyup',function(){
               var age = (this.value);
               if(age !==''){
              $.ajax({
                    'url': base_url + 'admin/Ajax_controller/age_to_birthdate/'+age.trim(),
                    'type': 'GET', 
                    'data': {'age': age },
                    'success': function(data) { 
                        var container = $(".birth_date");
                        if(data==0){
                            container.val("0000-00-00");
                        }else{ 
                            container.val(data); 
                        }
                    }
                });
            }
        });
    })

    // load patient name
    function load_patient_id(){ 
    'use strict';         
        var patient_id = document.getElementById('patient_id').value;
        var base_url = $("#base_url").val();
        if (patient_id!='') {
            
            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/get_patinet_id/'+patient_id.trim(),
                'type': 'GET', //the way you want to send data to your URL
                'data': {'patient_ibase_url': patient_id },
                'success': function(data) { 
                    var container = $(".p_id");
                    if(data==0){
                        container.html("<div class='alert alert-success'><span class='glyphicon glyphicon-ok'></span>Your id is available</div>");
                        $('button[type=submit]').prop('disabled', false);
                    }else{ 
                        container.html(data);
                        $('button[type=submit]').prop('disabled', true);
                    }
                }
            });
        };
    }


    $(document).ready(function(){
        'use strict';

        $("#male").hide();
        $("#female").hide();

        var sex = $('#psex').val();

        if(sex){
            if(sex==="Male"){
                $("#male").show();
                $("#female").hide();
            }else{
               $("#female").show();
             $("#male").hide();
            }
        }

       $("#checkbox2_5").on('click',function(){
            $("#male").show();
            $("#female").hide();
        });
        
        $("#checkbox2_10").on('click',function(){
            $("#female").show();
             $("#male").hide();
        });
        
        $("#checkbox2_0").on('click',function(){
            $("#male").show();
            $("#female").hide();
        });
        
    });

    // end create patient




    // get Sms template
    function getTeamplate(){
        'use strict';
        var base_url = $('#base_url').val();
        var teamplate_id = document.getElementById('tmp').value;
        
        $.ajax({ 
            'url': base_url + 'admin/Ajax_controller/get_teamplate/'+teamplate_id,
            'type': 'GET', //the way you want to send data to your URL
            'data': {'teamplate_id': teamplate_id },
            'success': function(d) { 
                var container = $(".view_tmp");
                if(d){
                    container.html(d);
                }else{ 
                    container.val(""); 
                }
            }
        });
        
    }


    
    function laodCata(lang_id){
         'use strict';
         var base_url = $('#base_url').val();
        if (lang_id!='') {
            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/lang_cata/'+lang_id,
                'type': 'GET', //the way you want to send data to your URL
                'data': {'lang_id': lang_id },
                'success': function(data) { 
                    
                    var container = $(".category");
                    if(data==0){
                        container.html("There is no category");
                    }else{ 
                        container.html(data);
                    }
                }
            });
        };
    }


    function loadClassi(cat_id){
        'use strict';
        var base_url = $('#base_url').val();
        if (cat_id!='') {
            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/cat_classification/'+cat_id,
                'type': 'GET', //the way you want to send data to your URL
                'data': {'cat_id': cat_id },
                'success': function(data) { 
                    
                    var container = $(".classi");
                    if(data==0){
                        container.html("There is no classification");
                    }else{ 
                        container.html(data);
                    }
                }
            });
        };
    }

    $(document).ready(function(){
        'use strict';
        var base_url=$('#base_url').val();

        $("#search-box").on('keyup',function(){

            var lang_id = $('#lang_id').val();
            var csrf_test_name = $("[name=csrf_test_name]").val();

            $('button[type=submit]').prop('disabled', true);

            $.ajax({
                type: "POST",
                url: base_url + 'admin/Ajax_controller/medicine_saj/',
                data: {lang_id: lang_id,keyword:$(this).val(),csrf_test_name:csrf_test_name},
                beforeSend: function(){
                    $("#search-box").css("background","#FFF url("+base_url+"assets/images/LoaderIcon.gif) no-repeat 165px");
                },
                success: function(data){
                    if(data){
                        $("#suggesstion-box").show();
                        $("#suggesstion-box").html(data);
                        $("#search-box").css("background","#FFF");
                       $('button[type=submit]').prop('disabled', false);
                    } else{
                        $("#suggesstion-box").hied();
                    }
                   
                }
            });
        });
    });

    'use strict';
    $(document).ready(function(){
        $('body').on('click','#country-list > li',function(){
            $("#search-box").val($(this).html());
            $("#search-medicine_id").val($(this).val());
            $("#country-list").slideUp(300);
        });
    });
        

function js_value(str)
{
    'use strict';
    var teamplate_name = $("#t_" + str).text();
    var teamplate = $("#td_" + str).text();
    $("#id").val(str);
    $("#template_name").val(teamplate_name);
    $("#teamplate").val(teamplate);
    $(".tit").text('SMS Template Setup');
    $("#MyForm").attr("action", 'template_edit');
    $(".sav_btn").text('Update');
}



function loadePattern(pattern){
    'use strict';
   var base_url = $('#base_url').val();
    $.ajax({
        'url': base_url + 'admin/Ajax_controller/patternSetData/'+pattern,
        'type': 'GET',
        'dataType': 'JSON',
        'success': function(data)
        {

            $('[name="h_height"]').val(data.h_height);
            $('[name="h_width"]').val(data.h_width);
            $('[name="f_height"]').val(data.f_height);
            $('[name="f_width"]').val(data.f_width);
            $('[name="content1_height"]').val(data.content1_height);
            $('[name="content1_width"]').val(data.content1_width);
            $('[name="content2_height"]').val(data.content2_height);
            $('[name="content2_width"]').val(data.content2_width);
        },
        'error': function (jqXHR, textStatus, errorThrown)
        {
            alert('Error get data from ajax');
        }
    });
}


function loadDisease(ms_id){
    'use strict';
        var base_url = $("#base_url").val();

        if (ms_id!='') {
                $.ajax({ 
                    'url': base_url + 'admin/Ajax_controller/load_disease/'+ms_id,
                    'type': 'GET', //the way you want to send data to your URL
                    'data': {'ms_id': ms_id },
                    'success': function(data) { 
                        
                        var container = $(".disease");
                        if(data==0){
                            container.html("There is no section");
                        }else{ 
                            container.html(data);
                         
                        }
                    }
                });
            };
    }
    // load  
    function loadSection(lang_id){  
       'use strict';
       var base_url = $("#base_url").val();
        if (lang_id!='') {
            $.ajax({ 
                'url': base_url + 'admin/Ajax_controller/lang_section/'+lang_id,
                'type': 'GET', //the way you want to send data to your URL
                'data': {'lang_id': lang_id },
                'success': function(data) { 
                    
                    var container = $(".section");
                    if(data==0){
                        container.html("There is no section");
                    }else{ 
                        container.html(data);
                     
                    }
                }
            });
        };
    }


    $(document).ready(function() {  

        var base_url = $('#base_url').val();
        
        $('.add-invoice').prop('disabled', true);

        $('body').on('keyup change', '#phone', function() {

            var phone = $(this).val();
            if(phone.length > 0)
            $.ajax({

                'url': base_url + 'admin/Ajax_controller/load_patient_info/'+phone,
                'type': 'GET',
                'dataType': 'JSON',
                'success': function(data){ 

                    if (data.patient_id) {

                        $('#patient_name').val(data.family_name);
                        $('#address').val(data.address);
                        $('#patient_id').val(data.patient_id);
                        $('#csc').removeClass('text-danger');
                        $(".invlid_patient_id").text(' Patient Pnone Number is Valid').addClass("text-success");
                       
                    } else {
                        $('#csc').removeClass('text-success');
                        $(".invlid_patient_id").text('Invalid Patient Phone Number').addClass("text-danger");
                    }
                }, error   : function() {
                    alert('failed!');
                } 
               
            });
        });

    });


    
    //print a div
    function printContent(el){
        'use strict';
        var restorepage  = $('body').html();
        var printcontent = $('#' + el).clone();
        $('body').empty().html(printcontent);
        window.print();
        $('body').html(restorepage);
        location.reload();
    }
